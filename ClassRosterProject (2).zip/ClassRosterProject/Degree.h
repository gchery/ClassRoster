#pragma once
using namespace std;

enum DegreeProgram{SECURITY, NETWORK, SOFTWARE};
